﻿namespace CRMSystem.Service
{
    public class Config
    {
        public static string ConnectionString { get; set; }
    }
}
