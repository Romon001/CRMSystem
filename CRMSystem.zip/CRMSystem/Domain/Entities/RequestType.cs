﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSystem.Domain.Entities
{
    public class RequestType
    {
        public int RequestTypeId { get; set; }
        public string Name { get; set; }
    }
}
